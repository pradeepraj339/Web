

function myFunction() {
   document.getElementById("demo").innerHTML = Date();
}